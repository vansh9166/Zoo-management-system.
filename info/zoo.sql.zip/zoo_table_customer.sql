
-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `Cid` varchar(15) NOT NULL,
  `CFname` varchar(30) NOT NULL,
  `CLname` varchar(30) NOT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Credit_Card_Info` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cid`, `CFname`, `CLname`, `Email`, `Address`, `Credit_Card_Info`) VALUES
('1', 'amal', 'sutone', 'amal@gmail.com', 'nagpur', '12233445533'),
('2', 'shubham', 'maratha', 'sm@gmail.com', 'bhilwara', '12323456765434'),
('3', 'babu', 'rao', 'bau@gmail.com', 'mumbai', '12345678987\r\n');


-- --------------------------------------------------------

--
-- Table structure for table `goes_to`
--

DROP TABLE IF EXISTS `goes_to`;
CREATE TABLE IF NOT EXISTS `goes_to` (
  `Cid` varchar(15) NOT NULL,
  `Zid` varchar(15) NOT NULL,
  PRIMARY KEY (`Cid`,`Zid`),
  KEY `fk2_gt_zid` (`Zid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

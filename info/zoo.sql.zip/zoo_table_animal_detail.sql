
-- --------------------------------------------------------

--
-- Table structure for table `animal_detail`
--

DROP TABLE IF EXISTS `animal_detail`;
CREATE TABLE IF NOT EXISTS `animal_detail` (
  `ADid` varchar(15) NOT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Aid` varchar(15) NOT NULL,
  PRIMARY KEY (`ADid`),
  KEY `fk_ad_aid` (`Aid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `animal_detail`
--

INSERT INTO `animal_detail` (`ADid`, `Height`, `Weight`, `Age`, `Aid`) VALUES
('51', '4 feet', '100 kg', 33, '1'),
('52', '5 feet', '120 kg', 43, '2');

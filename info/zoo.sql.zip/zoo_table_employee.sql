
-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `Eid` int(11) NOT NULL AUTO_INCREMENT,
  `EFname` varchar(30) NOT NULL,
  `ELname` varchar(30) NOT NULL,
  `Phone_No` varchar(30) NOT NULL,
  `Salary` int(11) NOT NULL,
  `Zid` varchar(15) NOT NULL,
  PRIMARY KEY (`Eid`),
  KEY `Zid` (`Zid`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Eid`, `EFname`, `ELname`, `Phone_No`, `Salary`, `Zid`) VALUES
(100, 'adarsh', 'parabhat', '987612344', 1000, '200'),
(101, 'prajoyat', 'sharma', '987613344', 2000, '201'),
(103, 'jacksx', 'chaudhary', '0712696969', 2400, '202');


-- --------------------------------------------------------

--
-- Table structure for table `manages`
--

DROP TABLE IF EXISTS `manages`;
CREATE TABLE IF NOT EXISTS `manages` (
  `Eid` varchar(15) NOT NULL,
  `Tid` varchar(15) NOT NULL,
  PRIMARY KEY (`Eid`,`Tid`),
  KEY `Tid` (`Tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

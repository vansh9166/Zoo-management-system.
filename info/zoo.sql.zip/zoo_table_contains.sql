
-- --------------------------------------------------------

--
-- Table structure for table `contains`
--

DROP TABLE IF EXISTS `contains`;
CREATE TABLE IF NOT EXISTS `contains` (
  `AKid` varchar(15) NOT NULL,
  `AGid` varchar(15) NOT NULL,
  PRIMARY KEY (`AKid`,`AGid`),
  KEY `fk2_contains_agid` (`AGid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `animal_kind`
--

DROP TABLE IF EXISTS `animal_kind`;
CREATE TABLE IF NOT EXISTS `animal_kind` (
  `AKid` varchar(15) NOT NULL,
  `AName` varchar(30) NOT NULL,
  `Physical_Characteristics` longtext NOT NULL,
  `Zoo_Region` varchar(50) NOT NULL,
  `Diet` varchar(30) NOT NULL,
  `Population_Status` varchar(30) NOT NULL,
  PRIMARY KEY (`AKid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `animal_kind`
--

INSERT INTO `animal_kind` (`AKid`, `AName`, `Physical_Characteristics`, `Zoo_Region`, `Diet`, `Population_Status`) VALUES
('21', 'sheru', 'Companies can analyse several batches of production and use broader data sets to alter the operating conditions and meet the quality specifications. This saves cost in avoiding off spec material. Further quality assurance can also help build better customer relationship', 'pune', 'non-veg', '5');

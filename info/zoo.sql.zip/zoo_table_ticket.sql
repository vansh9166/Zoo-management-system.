
-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `Tid` varchar(15) NOT NULL,
  `Price` int(11) NOT NULL,
  `Cid` varchar(15) NOT NULL,
  PRIMARY KEY (`Tid`),
  KEY `fk_ticket_cid` (`Cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
CREATE TABLE IF NOT EXISTS `features` (
  `Zid` int(11) NOT NULL,
  `AGid` int(11) NOT NULL,
  KEY `Zid` (`Zid`),
  KEY `AGid` (`AGid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

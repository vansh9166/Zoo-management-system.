
-- --------------------------------------------------------

--
-- Table structure for table `animal5`
--

DROP TABLE IF EXISTS `animal5`;
CREATE TABLE IF NOT EXISTS `animal5` (
  `Aid` varchar(15) NOT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Cage_Number` int(11) NOT NULL,
  `Feed_Time` varchar(30) NOT NULL,
  `AKid` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Aid`),
  KEY `AKid` (`AKid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `animal5`
--

INSERT INTO `animal5` (`Aid`, `Gender`, `Cage_Number`, `Feed_Time`, `AKid`) VALUES
('1', 'male', 1, '2:00-2:30pm', '21'),
('2', 'female', 2, '1:00-1:30pm', '22');

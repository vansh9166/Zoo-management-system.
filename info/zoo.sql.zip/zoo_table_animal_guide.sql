
-- --------------------------------------------------------

--
-- Table structure for table `animal_guide`
--

DROP TABLE IF EXISTS `animal_guide`;
CREATE TABLE IF NOT EXISTS `animal_guide` (
  `AGid` varchar(15) NOT NULL,
  `Zoo_Introduction` text NOT NULL,
  `Updated_Year` int(11) DEFAULT NULL,
  PRIMARY KEY (`AGid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

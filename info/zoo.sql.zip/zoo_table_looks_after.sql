
-- --------------------------------------------------------

--
-- Table structure for table `looks_after`
--

DROP TABLE IF EXISTS `looks_after`;
CREATE TABLE IF NOT EXISTS `looks_after` (
  `Eid` varchar(15) NOT NULL,
  `Aid` varchar(15) NOT NULL,
  PRIMARY KEY (`Eid`,`Aid`),
  KEY `fk2_looka_aid` (`Aid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `zoo`
--

DROP TABLE IF EXISTS `zoo`;
CREATE TABLE IF NOT EXISTS `zoo` (
  `Zid` int(11) NOT NULL AUTO_INCREMENT,
  `ZName` varchar(50) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Hours` varchar(100) NOT NULL,
  `Contact` varchar(100) NOT NULL,
  `AGid` varchar(15) NOT NULL,
  PRIMARY KEY (`Zid`),
  KEY `fk_zoo_AGid` (`AGid`),
  KEY `Zid` (`Zid`),
  KEY `Zid_2` (`Zid`)
) ENGINE=MyISAM AUTO_INCREMENT=1013 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zoo`
--

INSERT INTO `zoo` (`Zid`, `ZName`, `Location`, `Hours`, `Contact`, `AGid`) VALUES
(1001, 'RG', 'Goa', '12pm-10pm', '8787878789', '103'),
(1002, 'ANNA', 'CHENNAI', '9:00 am - 5:00 pm', '9898989238', '101'),
(1007, 'APPA', 'PUNE', '7am-4pm', '8787878799', '201'),
(1012, '12', 'xyz', '10', '7272727272', '111');
